<style type="text/css">
    .bs-sw{
    	margin: 5px;
        padding: 10px;
        font-size:15px;
        font-weight:bold;
       

       
    }
  

.navbar-custom {
    background-color:#135A71;
    color:#ffffff;
    border-radius:0;
}

.navbar-custom .navbar-nav > li > a {
    color:#fff;
}

.navbar-custom .navbar-nav > .active > a {
    color: #ffffff;
    background-color:transparent;
}

.navbar-custom .navbar-nav > li > a:hover,
.navbar-custom .navbar-nav > li > a:focus,
.navbar-custom .navbar-nav > .active > a:hover,
.navbar-custom .navbar-nav > .active > a:focus,
.navbar-custom .navbar-nav > .open >a {
    text-decoration: none;
    background-color: #FFAB32;
}

.navbar-custom .navbar-brand {
    color:#eeeeee;
}
.navbar-custom .navbar-toggle {
    background-color:#eeeeee;
}
.navbar-custom .icon-bar {
    background-color:#FFAB32;
}

</style>

<div class="bs-sw">
<nav role="navigation" class="navbar navbar-custom navbar-fixed-top">
        <!-- Brand and toggle get grouped for better mobile display -->
        
        <div class="navbar-header">
            
            
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">

                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
<a class="navbar-brand" href="https://moedasdigitais.nl">MD</a>

         </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              
<li class="dropdown"><a href="https://nbrservices.niobiocash.nl">NBRSERVICES</a></li>
 
<li class="dropdown"><a href="https://niobiocash.nl/parceiros">Parceiros</a></li>

<li class="dropdown"><a href="https://moedasdigitais.nl/wc/nbr/parceiros" >Carteiras </a></li>

<li class="dropdown"><a href="https://niobiocash.nl/markets" >Exchanges</a></li>
         
</ul>

            <ul class="nav navbar-nav navbar-right">
                            
           

<li><a href="http://niobiocash.moedasdigitais.nl">NIOBIOCASH.NL</a></li>

            
            </ul>
            
            
        </div>

</div>