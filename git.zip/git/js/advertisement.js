isAdBlockActive=false;
