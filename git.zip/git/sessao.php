
<span id="sessao"><h4>Game Expira em: </h4><br />  <b><?php  echo "$tempoexperia"; ?> Minutos </b> </span>



