<?php
include("config.php");
include("top.php");
?>
<h1>ERRO 404</h1>
<h3>Nada encontrado!</h3>
<?php
include("out.php");
?>